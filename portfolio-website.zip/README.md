# Modern Developer Portfolio Website

A responsive, high-performance personal portfolio website engineered specifically for **Full-Stack Developers, Project Developers, and Software Engineers**. Built with clean architecture, semantic HTML5, modern Tailwind CSS, and vanilla JavaScript.

---

## 🌟 Key Features

- **Hero & Value Proposition:** High-impact headlines, status availability badge, core technology ticker, and quantified metrics bar.
- **Narrative About Section:** Emphasizes engineering philosophy, problem-solving mindset, and delivery reliability.
- **Interactive Skills Matrix:** Tabbed domain filtering across Frontend, Backend, Databases, Cloud & DevOps, Architecture, and Testing.
- **Featured Case Studies:** Deep-dive cards detailing Problem Statements, Technical Solutions, Tech Stacks, and Quantified Business Impact metrics.
- **Interactive Architecture Modal:** Clickable deep dives into system workflows, data ingestion layers, and engineering tradeoffs.
- **Structured 4-Step Methodology:** Discovery & Scope $\rightarrow$ Architecture $\rightarrow$ Agile Execution & QA $\rightarrow$ Cloud Deploy.
- **Interactive Contact Section:** Working contact form simulation with loading state, social links (GitHub, LinkedIn, Calendly), and one-click copy-to-clipboard email with instant toast notifications.
- **Dark & Light Mode:** Seamless theme toggle with local storage state persistence.
- **Zero Build Step Required:** Runs directly out of the box in any browser or local web server.

---

## 🚀 Quick Start / How to Run

### Option 1: Open Directly in Browser
Simply double-click `index.html` or drag it into any modern web browser (Chrome, Edge, Firefox, Safari).

### Option 2: Run with Python Built-in Server
Open your terminal in this directory and execute:
```bash
python -m http.server 8000
```
Then navigate to `http://localhost:8000` in your browser.

### Option 3: Run with Node.js
If you have `npx` installed:
```bash
npx serve .
```

---

## 📁 File Structure

```
portfolio-website/
├── index.html       # Semantic HTML5 layout with Tailwind CSS & Lucide icons
├── styles.css       # Custom theme rules, light/dark overrides & animations
├── app.js           # Theme toggler, modal controller, skill filtering & toasts
└── README.md        # Documentation and deployment guide
```

---

## ✏️ Customization Checklist

1. **Name & Title:** Search for `Alex Rivera` in `index.html` and replace it with your full name.
2. **Contact Email:** Update `alex.rivera.dev@example.com` in `index.html` and `app.js`.
3. **Social Links:** Replace the placeholders for GitHub, LinkedIn, and Calendly links in the `#contact` section.
4. **Projects & Metrics:** Update the case studies in `index.html` and `projectData` inside `app.js` with your own projects and real-world statistics.
5. **Skills:** Modify the tags in the `#skills` section to reflect your primary tech stack.

---

## 🌐 Free Instant Deployment

- **GitHub Pages:** Push this repository to GitHub, go to **Settings $\rightarrow$ Pages**, and select the `main` branch root.
- **Vercel:** Drag and drop the folder into [vercel.com/new](https://vercel.com/new) or run `npx vercel`.
- **Netlify:** Drag and drop the folder directly into [app.netlify.com/drop](https://app.netlify.com/drop).
