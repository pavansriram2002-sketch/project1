// Alex Rivera Portfolio JavaScript Logic

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide Icons
  if (window.lucide) {
    lucide.createIcons();
  }

  initTheme();
  initMobileMenu();
  initSkillFilter();
  initScrollSpy();
  updateEmailDisplays();
});

// 1. Theme Management (Dark / Light)
function initTheme() {
  const themeToggle = document.getElementById('theme-toggle');
  const html = document.documentElement;

  // Check saved theme or default to dark
  const savedTheme = localStorage.getItem('portfolio-theme') || 'dark';
  if (savedTheme === 'light') {
    html.classList.remove('dark');
  } else {
    html.classList.add('dark');
  }

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      if (html.classList.contains('dark')) {
        html.classList.remove('dark');
        localStorage.setItem('portfolio-theme', 'light');
      } else {
        html.classList.add('dark');
        localStorage.setItem('portfolio-theme', 'dark');
      }
      if (window.lucide) {
        lucide.createIcons();
      }
    });
  }
}

// 2. Mobile Navigation Toggle
function initMobileMenu() {
  const btn = document.getElementById('mobile-menu-btn');
  const menu = document.getElementById('mobile-menu');
  const links = document.querySelectorAll('.mobile-nav-link');

  if (btn && menu) {
    btn.addEventListener('click', () => {
      menu.classList.toggle('hidden');
    });

    links.forEach(link => {
      link.addEventListener('click', () => {
        menu.classList.add('hidden');
      });
    });
  }
}

// 3. Skill Category Filter
function initSkillFilter() {
  const filterButtons = document.querySelectorAll('.skill-tab-btn');
  const skillCards = document.querySelectorAll('.skill-card');

  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      // Toggle active button
      filterButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');

      const category = button.getAttribute('data-category');

      skillCards.forEach(card => {
        const domain = card.getAttribute('data-domain');
        if (category === 'all' || domain === category) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

// 4. Scroll Spy Navigation Highlight
function initScrollSpy() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    const scrollPos = window.pageYOffset + 200;

    sections.forEach(section => {
      const top = section.offsetTop;
      const height = section.offsetHeight;
      if (scrollPos >= top && scrollPos < top + height) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('text-brand-400');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('text-brand-400');
      }
    });
  });
}

// 5. Toast Notifications
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl border text-xs font-mono shadow-2xl backdrop-blur-md ${
    type === 'success' 
      ? 'bg-slate-900/95 border-emerald-500/50 text-emerald-300' 
      : 'bg-slate-900/95 border-rose-500/50 text-rose-300'
  }`;

  const iconName = type === 'success' ? 'check-circle' : 'alert-circle';
  toast.innerHTML = `
    <i data-lucide="${iconName}" class="w-4 h-4 text-emerald-400"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  if (window.lucide) lucide.createIcons();

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// 6. Copy Email to Clipboard
function copyEmailToClipboard() {
  const emailText = document.getElementById('email-text').innerText.trim();
  const copyBtn = document.getElementById('copy-email-btn');

  navigator.clipboard.writeText(emailText).then(() => {
    showToast('Email address copied to clipboard!');
    if (copyBtn) {
      copyBtn.innerHTML = '<i data-lucide="check" class="w-4 h-4 text-emerald-400"></i>';
      if (window.lucide) lucide.createIcons();
      setTimeout(() => {
        copyBtn.innerHTML = '<i data-lucide="copy" class="w-4 h-4"></i>';
        if (window.lucide) lucide.createIcons();
      }, 2000);
    }
  }).catch(() => {
    showToast('Failed to copy. Please manually select the email.', 'error');
  });
}

// 7. Interactive Project Architecture Modal
const projectData = {
  fleet: {
    title: 'Cloud-Native Logistics & Fleet Tracking Dashboard',
    tagline: 'High-Throughput Telemetry Pipeline & Live Geospatial Telematics',
    architecture: [
      { step: 'Ingestion Layer', desc: 'Asynchronous Node.js microservice receiving MQTT & HTTP vehicle pings at 500+ events/sec.' },
      { step: 'Buffer & Pub/Sub', desc: 'Redis queue buffering raw geo-coordinates and distributing packets to consumer workers.' },
      { step: 'Persistence & Geospatial Querying', desc: 'PostgreSQL with PostGIS indexing calculating distance, idle fuel burns, and route deviations.' },
      { step: 'Real-Time Broadcast', desc: 'WebSocket channels broadcasting clustered GPS coordinates directly to dispatcher dashboards in <400ms.' }
    ],
    techStack: ['Next.js 14', 'TypeScript', 'Node.js', 'PostgreSQL', 'Redis', 'Docker', 'AWS ECS', 'WebSockets', 'Tailwind CSS'],
    keyTakeaway: 'Architecting for sub-second telemetry required replacing traditional polling with Redis Pub/Sub and WebSockets, cutting server load by 48% while boosting real-time tracking fidelity.'
  },
  billing: {
    title: 'Automated Billing & Subscription SaaS Engine',
    tagline: 'Multi-Tenant Financial Engine with Idempotent Payment Pipelines',
    architecture: [
      { step: 'Contract Definition', desc: 'Pydantic-validated REST APIs handling complex multi-seat tiered subscriptions and seat adds.' },
      { step: 'Idempotency & Webhooks', desc: 'Secure Stripe Webhook consumer with SHA256 signature verification and replay attack protection.' },
      { step: 'ACID Ledger Accounting', desc: 'PostgreSQL transactional state machine ensuring no double-charges during network dropouts.' },
      { step: 'Smart Dunning & Recovery', desc: 'Automated retry intervals and webhook-triggered dunning sequence that reduced involuntary churn by 12%.' }
    ],
    techStack: ['Python', 'FastAPI', 'React', 'PostgreSQL', 'Stripe API', 'Docker', 'GitHub Actions', 'Pytest', 'Chart.js'],
    keyTakeaway: 'Financial software demands absolute idempotency. Implementing transactional outbox patterns ensured 100% financial consistency across $1.2M+ in processed transactions.'
  }
};

function openProjectModal(key) {
  const modal = document.getElementById('project-modal');
  const content = document.getElementById('modal-content');
  const data = projectData[key];

  if (!data || !modal || !content) return;

  let archHtml = data.architecture.map((item, idx) => `
    <div class="flex items-start gap-4 p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
      <div class="w-6 h-6 rounded-full bg-brand-500/20 text-brand-400 flex items-center justify-center text-xs font-mono font-bold flex-shrink-0">
        ${idx + 1}
      </div>
      <div>
        <div class="text-xs font-semibold text-white font-mono">${item.step}</div>
        <div class="text-xs text-slate-400 mt-0.5 leading-relaxed">${item.desc}</div>
      </div>
    </div>
  `).join('');

  let tagsHtml = data.techStack.map(tag => `
    <span class="skill-tag">${tag}</span>
  `).join('');

  content.innerHTML = `
    <div class="space-y-6">
      <div>
        <span class="text-xs font-mono uppercase tracking-widest text-brand-400 font-semibold">Architectural Deep Dive</span>
        <h3 class="text-xl sm:text-2xl font-bold text-white mt-1">${data.title}</h3>
        <p class="text-xs sm:text-sm text-slate-400 mt-1">${data.tagline}</p>
      </div>

      <div>
        <h4 class="text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 mb-3">System Architecture Pipeline</h4>
        <div class="space-y-2.5">
          ${archHtml}
        </div>
      </div>

      <div>
        <h4 class="text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 mb-2">Technologies Used</h4>
        <div class="flex flex-wrap gap-2">
          ${tagsHtml}
        </div>
      </div>

      <div class="p-4 rounded-xl bg-brand-950/30 border border-brand-800/40">
        <h4 class="text-xs font-mono font-semibold text-brand-400 uppercase tracking-wider mb-1">Key Engineering Takeaway</h4>
        <p class="text-xs text-slate-300 leading-relaxed">${data.keyTakeaway}</p>
      </div>
    </div>
  `;

  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  if (window.lucide) lucide.createIcons();
}

function closeProjectModal() {
  const modal = document.getElementById('project-modal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = '';
  }
}

// Close modal on click outside
window.addEventListener('click', (e) => {
  const modal = document.getElementById('project-modal');
  if (e.target === modal) {
    closeProjectModal();
  }
});

// Close modal on Escape key
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeProjectModal();
  }
});

// 8. Recipient Email Management
function getRecipientEmail() {
  return localStorage.getItem('portfolio-recipient-email') || 'alex.rivera.dev@example.com';
}

function setRecipientEmail(newEmail) {
  if (!newEmail || !newEmail.includes('@')) {
    showToast('Please enter a valid email address.', 'error');
    return false;
  }
  localStorage.setItem('portfolio-recipient-email', newEmail.trim());
  updateEmailDisplays();
  showToast(`Recipient email updated to: ${newEmail.trim()}`);
  return true;
}

function updateEmailDisplays() {
  const email = getRecipientEmail();
  const textEl = document.getElementById('email-text');
  const previewEl = document.getElementById('form-recipient-email');
  if (textEl) textEl.innerText = email;
  if (previewEl) previewEl.innerText = email;
}

function promptChangeEmail() {
  const current = getRecipientEmail();
  const input = prompt('Enter your destination email address (where you want enquiries sent):', current);
  if (input !== null && input.trim() !== '') {
    setRecipientEmail(input.trim());
  }
}

// 9. Real Contact Form Submission (FormSubmit.co + Local Server API + Mailto Fallback)
async function handleContactSubmit(event) {
  event.preventDefault();
  const submitBtn = document.getElementById('submit-btn');
  const form = document.getElementById('contact-form');
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const subject = document.getElementById('subject').value;
  const message = document.getElementById('message').value.trim();
  const recipientEmail = getRecipientEmail();

  if (!name || !email || !message) {
    showToast('Please fill out all required fields.', 'error');
    return;
  }

  if (submitBtn) {
    const originalContent = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
      <span>Delivering to ${recipientEmail}...</span>
    `;

    const payload = {
      name: name,
      email: email,
      subject: subject,
      message: message,
      _subject: `[Portfolio Inquiry] ${subject} from ${name}`,
      _replyto: email,
      _template: 'table'
    };

    let deliveredViaFormSubmit = false;
    let savedLocally = false;

    // 1. Send via FormSubmit to deliver actual email to recipient's inbox
    try {
      const fsResponse = await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(recipientEmail)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
      });
      const fsData = await fsResponse.json();
      if (fsResponse.ok && (fsData.success === 'true' || fsData.success === true)) {
        deliveredViaFormSubmit = true;
      }
    } catch (err) {
      console.warn('FormSubmit network call failed or offline:', err);
    }

    // 2. Also save to local server backend (/api/contact) if running locally
    try {
      const localResponse = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (localResponse.ok) {
        savedLocally = true;
      }
    } catch (err) {
      console.log('Local server endpoint not available or running statically');
    }

    // Reset button
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalContent;
    if (window.lucide) lucide.createIcons();

    if (deliveredViaFormSubmit || savedLocally) {
      form.reset();
      
      let successMsg = `Enquiry sent! Dispatched directly to ${recipientEmail}.`;
      if (savedLocally) {
        successMsg += ` (Also archived to local inquiries.json).`;
      }
      showToast(successMsg, 'success');

      // Check if this might be first time FormSubmit delivery to show activation reminder
      const hasActivated = localStorage.getItem(`fs-activated-${recipientEmail}`);
      if (!hasActivated) {
        localStorage.setItem(`fs-activated-${recipientEmail}`, 'true');
        setTimeout(() => {
          showToast(`Note: If this is the first submission to ${recipientEmail}, check your inbox for an activation confirmation link from FormSubmit.`, 'success');
        }, 3500);
      }
    } else {
      // Fallback: offer mailto link if completely offline
      showToast(`Network error. Opening your default email client as fallback...`, 'error');
      const mailtoUrl = `mailto:${encodeURIComponent(recipientEmail)}?subject=${encodeURIComponent('[Portfolio] ' + subject + ' from ' + name)}&body=${encodeURIComponent('From: ' + name + ' (' + email + ')\n\n' + message)}`;
      window.location.href = mailtoUrl;
    }
  }
}
