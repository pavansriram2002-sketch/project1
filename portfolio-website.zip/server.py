import http.server
import socketserver
import json
import os
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.error import URLError

PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))
INQUIRIES_FILE = os.path.join(DIRECTORY, "inquiries.json")

class PortfolioHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def do_POST(self):
        if self.path == "/api/contact":
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length)
            
            try:
                data = json.loads(post_data.decode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"status": "error", "message": "Invalid JSON"}).encode("utf-8"))
                return

            # Add timestamp and metadata
            data["received_at"] = datetime.now().isoformat()
            data["client_ip"] = self.client_address[0]

            # Save locally to inquiries.json
            inquiries = []
            if os.path.exists(INQUIRIES_FILE):
                try:
                    with open(INQUIRIES_FILE, "r", encoding="utf-8") as f:
                        inquiries = json.load(f)
                except Exception:
                    inquiries = []
            
            inquiries.append(data)
            with open(INQUIRIES_FILE, "w", encoding="utf-8") as f:
                json.dump(inquiries, f, indent=2)

            print(f"\n[NEW INQUIRY RECEIVED]")
            print(f"From: {data.get('name')} <{data.get('email')}>")
            print(f"Subject: {data.get('subject')}")
            print(f"Message: {data.get('message')}")
            print(f"Saved locally to: {INQUIRIES_FILE}\n")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            response = {
                "status": "success",
                "message": "Inquiry recorded successfully and saved to local inquiries.json",
                "saved_locally": True
            }
            self.wfile.write(json.dumps(response).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), PortfolioHandler) as httpd:
        print(f"Portfolio server running at http://localhost:{PORT}")
        print(f"Inquiries will be automatically saved to {INQUIRIES_FILE}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server.")
